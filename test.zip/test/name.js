exports.sayName = function(){
	console.log('hi my name is travler');
};