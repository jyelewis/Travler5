$("#btnBell").click(function(){
	window.emit('bell');
});